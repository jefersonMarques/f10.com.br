<script lang="ts">
  import "../app.css";
  import { onMount } from "svelte";
  import { afterNavigate } from "$app/navigation";

  import Header from "$lib/components/Header.svelte";
  import Footer from "$lib/components/Footer.svelte";
  import Popup, { type PopupSize } from "$lib/components/popup/Popup.svelte";
  import PopupSolutionsList from "$lib/components/popup/PopupSolutionsList.svelte";

  import ContactWhatsappModalForm from "$lib/components/forms/ContactModalForm.svelte";
  import FloatingWhatsappButton from "$lib/components/forms/FloatingWhatsappButton.svelte";
  import { contactModalConfig } from "$lib/stores/contactModals";
  import SolutionList from "$lib/components/forms/SolutionList.svelte";

  type FbqFunction = (...args: unknown[]) => void;

  let modalSize: PopupSize = "xl";

  $: modalConfig = $contactModalConfig;

  onMount(() => {
    afterNavigate(() => {
      const fbq = (window as Window & { fbq?: FbqFunction }).fbq;
      fbq?.("track", "PageView");
    });
  });
</script>

<svelte:head>
  <meta name="theme-color" content="#ffffff" />
  <meta
    name="description"
    content="F10 Software — Plataforma completa de gestão escolar com alta performance."
  />
  <meta property="og:type" content="website" />
  <meta property="og:site_name" content="F10 Software" />
  <link rel="icon" href="/favicon.png" />
</svelte:head>

<div
  class="min-h-screen text-slate-900 flex flex-col
         bg-[#dfe1f5]/[0.20]
         backdrop-blur-[2px] supports-[backdrop-filter]:backdrop-blur-[0.5px]"
>
  <Header />
  <main class="flex-1">
    <slot />
  </main>
  <Footer />
</div>

<FloatingWhatsappButton
  whatsAppNumber="5541992943443"
  defaultMessage="Olá, vi a página de planos da F10 e quero entender qual é o melhor para a minha escola."
  product="F10 – Planos e Implantação"
  page=""
  subSource="Botão flutuante"
  leadDescription="Cliente interessado."
/>

<Popup size={modalSize}>
  <ContactWhatsappModalForm
    whatsAppNumber="5541992943443"
    defaultMessage={modalConfig.defaultMessage}
    product={modalConfig.product}
    subSource={modalConfig.subSource}
    leadDescription={modalConfig.leadDescription}
    onChangeSize={(s) => (modalSize = s)}
  />
</Popup>

<PopupSolutionsList size={modalSize}>
  <SolutionList />
</PopupSolutionsList>
